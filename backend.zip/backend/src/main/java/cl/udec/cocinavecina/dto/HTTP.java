package cl.udec.cocinavecina.dto;

public final class HTTP {
    private HTTP(){}
    public record Response(int status){
        public static final Response FORBIDDEN = new Response(403);
        public static final Response NOT_FOUND = new Response(404);
        public static final Response CONFLICT = new Response(409);
    }

}
