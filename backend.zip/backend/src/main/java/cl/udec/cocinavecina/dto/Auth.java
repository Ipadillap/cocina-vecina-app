package cl.udec.cocinavecina.dto;

import cl.udec.cocinavecina.model.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public final class Auth {
    private Auth(){}

    public record SignUpRequest(@NotBlank @Email String email,
                                @NotBlank String displayName,
                                @NotBlank @Size(min = 10) String password,
                                @NotNull Role role
    ) {}

    public record LoginRequest(@NotBlank @Email String email,
                               @NotBlank String password
    ) {}

    public record TokenResponse(String accessToken,
                                long expiresInSeconds,
                                long userId,
                                Role role
    ) {}
}
