package cl.udec.cocinavecina.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PickUpPointView {
    private int id;
    private String alias;
    private int approxLatitude;
    private int approxLongitude;

}
