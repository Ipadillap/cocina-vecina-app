package cl.udec.cocinavecina.components;

import cl.udec.cocinavecina.dto.Auth;
import cl.udec.cocinavecina.model.AppUser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.JwsHeader;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;

import java.time.Duration;
import java.time.Instant;
import java.util.List;

public class TokenIssuer {
    private final JwtEncoder encoder;
    private final Duration ttl;

    TokenIssuer(JwtEncoder encoder, @Value("${cocinavecina.jwt.access-token-ttl}") Duration ttl){
        this.encoder = encoder;
        this.ttl = ttl;
    }

    Auth.TokenResponse issue(AppUser user){
        Instant now = Instant.now();
        JwtClaimsSet claims = JwtClaimsSet.builder()
            .issuer("cocinavecina")
            .issuedAt(now)
            .expiresAt(now.plus(ttl))
            .subject(String.valueOf(user.getId()))
            .claim("roles", List.of(user.getRole().name()))
            .build();
        String token = encoder.encode(JwtEncoderParameters.from(
            JwsHeader.with(MacAlgorithm.HS256).build(), claims)).getTokenValue();
        return new Auth.TokenResponse(token,ttl.getSeconds(), user.getId(), user.getRole());
    }
}
