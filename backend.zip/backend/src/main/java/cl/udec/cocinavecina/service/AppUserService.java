package cl.udec.cocinavecina.service;

import cl.udec.cocinavecina.dto.CreateUserRequest;
import cl.udec.cocinavecina.exception.ApiException;
import cl.udec.cocinavecina.model.AppUser;
import cl.udec.cocinavecina.repository.AppUserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppUserService {
    private final AppUserRepository appUserRepository;

    public AppUserService(AppUserRepository appUserRepository){
        this.appUserRepository = appUserRepository;
    }

    public AppUser createUser(CreateUserRequest request) {
        List<String> detail = request.validRequest(this);
        if (!detail.isEmpty()) {
            throw ApiException.builder()
                .title().status().message().build()
                .build();
        }
    }


    public List<String> currentDisplayNames(){
        return appUserRepository.findAll().stream().map(AppUser::getDisplayName).toList();
    }

    public List<String> currentEmails(){
        return appUserRepository.findAll().stream().map(AppUser::getEmail).toList();
    }
    // falta desincreptar
    public List<String> currentPhones(){
        return appUserRepository.findAll().stream().map(AppUser::getEncryptedPhone).toList();
    }


}
