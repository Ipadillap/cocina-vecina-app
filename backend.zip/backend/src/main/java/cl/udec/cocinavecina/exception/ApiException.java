package cl.udec.cocinavecina.exception;

import cl.udec.cocinavecina.dto.ApiResponse;
import cl.udec.cocinavecina.dto.HTTP;
import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
public class ApiException extends RuntimeException {
    private final ApiResponse response;

    @Builder
    public ApiException(String title,
                        HTTP.Response status,
                        String message,
                        List<String> detail) {
        super(message);
        this.response = new ApiResponse(title, status.status(), detail);
    }
}
