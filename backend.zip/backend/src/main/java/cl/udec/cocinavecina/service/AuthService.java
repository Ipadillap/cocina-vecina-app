package cl.udec.cocinavecina.service;

import cl.udec.cocinavecina.components.TokenIssuer;
import cl.udec.cocinavecina.dto.Auth;
import cl.udec.cocinavecina.dto.HTTP;
import cl.udec.cocinavecina.exception.ApiException;
import cl.udec.cocinavecina.model.Role;
import cl.udec.cocinavecina.repository.AppUserRepository;
import jakarta.transaction.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final AppUserRepository users;
    private final PasswordEncoder encoder;
    private final TokenIssuer tokenIssuer;

    AuthService(AppUserRepository users,PasswordEncoder encoder, TokenIssuer tokenIssuer){
        this.users = users;
        this.encoder = encoder;
        this.tokenIssuer = tokenIssuer;
    }
    @Transactional
    Auth.TokenResponse register(Auth.SignUpRequest request){
        if(request.role() == Role.MODERATOR){
            throw ApiException.builder()
                .title("Prohibido 67")
                .status(HTTP.Response.FORBIDDEN)
                .message("El rol administrador no se obtiene por registro")
                .build();
        }
        if(users.existsByEmail((request.email().toLowerCase()){
            throw ApiException.builder()
                .title("Forbidden")
                .status(HTTP.Response.CONFLICT)
                .message("El rol administrador no se obtiene por registro")
                .build();
        }
    }

}
