package cl.udec.cocinavecina.service;

import cl.udec.cocinavecina.dto.PickUpPointView;
import cl.udec.cocinavecina.repository.OfferRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OfferService {
    OfferRepository offerRepository;

    public OfferService(OfferRepository offerRepository){
        this.offerRepository = offerRepository;
    }

    public List<PickUpPointView> pickUpPoints()

}
