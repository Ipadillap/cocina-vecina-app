package cl.udec.cocinavecina.dto;

import cl.udec.cocinavecina.model.AccountStatus;
import cl.udec.cocinavecina.service.AppUserService;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public record CreateUserRequest (

    String displayName,
    String email,
    String password,
    String phone,
    boolean adult_declared,
    AccountStatus status

){
    // Standard email format pattern
    private static final String EMAIL_REGEX =
        "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";

    // Password: Min 8 chars, at least 1 uppercase, 1 lowercase, 1 number, 1 special char
    private static final String PASSWORD_REGEX =
        "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";

    private static final String CHILE_MOBILE_REGEX = "^(\\+?56)?\\s*(?:0?9)?\\s*[2-9]\\d{7}$";


    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(PASSWORD_REGEX);
    private static final Pattern PHONE_PATTERN = Pattern.compile(CHILE_MOBILE_REGEX);

    public List<String> validRequest(AppUserService service) {
        List<String> detail = new ArrayList<>();
        List<String> currentEmails = service.currentEmails();
        List<String> currentDisplayNames = service.currentEmails();
        List<String> currentPhones = service.currentPhones();

        detail.addAll(validatingEmail(currentEmails, this.email));
        detail.addAll(validatingDisplayName(currentDisplayNames, this.displayName));
        detail.addAll(validatingPassword(this.password));
        detail.addAll(validatingPhone(currentPhones, phone));
        return detail;
    }

    private List<String> validatingEmail(List<String> currentEmails,String email){
        List<String> detail = new ArrayList<>();
        if (email.isEmpty()){
            detail.add("El correo electronico está vacio.");
        }
        if(currentEmails.contains(email)){
            detail.add("Ya existe una cuenta con el correo electronico.");
        }
        if (!EMAIL_PATTERN.matcher(email).matches()){
            detail.add("Formato del correo electronico no es correcto.");
        }

        return detail;
    }

    private List<String> validatingDisplayName(List<String> currentDisplayNames,String displayName){
        List<String> detail = new ArrayList<>();
        if (displayName.isEmpty()){
            detail.add("El nombre de usuario está vacio.");
        }
        if(currentDisplayNames.contains(displayName)){
            detail.add("Ya existe una cuenta con ese nombre de usuario.");
        }
        return detail;
    }

    private List<String> validatingPhone(List<String> currentPhones,String phone){
        List<String> detail = new ArrayList<>();
        if (phone.isEmpty()){
            detail.add("El telefono no puede estar vacio.");
        }
        if(currentPhones.contains(phone)){
            detail.add("Ya existe una cuenta con este numero de telefono.");
        }

        if(!PHONE_PATTERN.matcher(phone).matches()){
            detail.add("El formato del celular no es el adecuado");
        }
        return detail;
    }
    private List<String> validatingPassword(String password){
        List<String> detail = new ArrayList<>();

        if (password.isEmpty()){
            detail.add("La contraseña no puede estar vacia.");
        }
        if(!PASSWORD_PATTERN.matcher(password).matches()){
            detail.add("El formato de la contraseña no es correcta");
        }

        return detail;
    }
}
